Shared library to get difference between branches of OS Alt linux packages

Steps for setup librory:
