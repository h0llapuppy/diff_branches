Shared library to get difference between OS Alt linux dev branch packages

Steps for setup library:

sudo apt-get 
update apt-get install python3

git clone https://github.com/h0llapuppy/diff_branches.git

tar xvzf get_diff_branches-1.0.tar.gz

cd get_diff_branches-1.0/

sudo python3 setup.py install